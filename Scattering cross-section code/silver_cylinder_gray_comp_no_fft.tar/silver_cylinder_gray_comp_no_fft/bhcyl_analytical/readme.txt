gfortran *f -o bhcyl_exec
chmod a+x bhcyl_exec

